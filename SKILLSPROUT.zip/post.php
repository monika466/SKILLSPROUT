<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// DB credentials
$host = "localhost";
$username = "root";
$password = "";
$dbname = "skill";

// Connect to DB
$conn = new mysqli($host, $username, $password, $dbname);

// Connection check
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect form data
$projectTitle = $_POST['projectTitle'];
$description = $_POST['description'];
$deadline = $_POST['deadline'];
$budget = $_POST['budget'];
$eligibility = $_POST['eligibility'];
$skills = $_POST['skills'];

// Handle file upload
$samples = '';
if (isset($_FILES['samples']) && $_FILES['samples']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = "uploads/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true); // create folder if not exist
    }

    $fileName = basename($_FILES['samples']['name']);
    $targetPath = $uploadDir . time() . "_" . $fileName;

    if (move_uploaded_file($_FILES['samples']['tmp_name'], $targetPath)) {
        $samples = $targetPath;
    } else {
        echo "<script>alert('File upload failed!'); window.history.back();</script>";
        exit();
    }
}

// Insert into DB
$sql = "INSERT INTO job_posts (project_title, description, samples, deadline, budget, eligibility, skills) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssss", $projectTitle, $description, $samples, $deadline, $budget, $eligibility, $skills);

if ($stmt->execute()) {
    echo "<script>
        alert('🎉 Job Posted Successfully!');
        window.location.href = 'my-jobs.php';
    </script>";
} else {
    echo "<script>
        alert('Error: " . $stmt->error . "');
        window.history.back();
    </script>";
}

$stmt->close();
$conn->close();
?>
