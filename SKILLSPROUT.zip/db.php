<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "skill"; // Make sure this DB exists

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Upload file (if any)
$filename = "";
if (isset($_FILES["samples"]) && $_FILES["samples"]["error"] == 0) {
    $filename = basename($_FILES["samples"]["name"]);
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir);
    }
    move_uploaded_file($_FILES["samples"]["tmp_name"], $target_dir . $filename);
}

// Get form data
$title = $_POST['projectTitle'];
$desc = $_POST['description'];
$deadline = $_POST['deadline'];
$budget = $_POST['budget'];
$level = $_POST['eligibility'];
$skills = $_POST['skills'];

$sql = "INSERT INTO jobs (title, description, file_name, deadline, budget, experience_level, skills)
        VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssss", $title, $desc, $filename, $deadline, $budget, $level, $skills);

if ($stmt->execute()) {
    header("Location: my-jobs.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
