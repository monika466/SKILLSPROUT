<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to database
$host = "localhost";
$username = "root";
$password = "";
$dbname = "skill";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"] ?? '');
    $email = trim($_POST["email"] ?? '');
    $portfolio = trim($_POST["portfolio"] ?? '');
    $message = trim($_POST["message"] ?? '');

    // Basic validation
    if (empty($name) || empty($email) || empty($message)) {
        echo "<script>alert('Please fill all required fields.'); window.history.back();</script>";
        exit();
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO applications (name, email, portfolio, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $portfolio, $message);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Application submitted successfully!'); window.location.href='explore.html';</script>";
    } else {
        echo "<script>alert('❌ Submission failed. Please try again.'); window.history.back();</script>";
    }

    $stmt->close();
}

$conn->close();
?>
