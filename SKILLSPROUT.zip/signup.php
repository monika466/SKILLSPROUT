<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// DB Connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "skill";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $role = $_POST['role'] ?? '';
    $fullName = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $rawPassword = $_POST['password'] ?? '';

    if (!in_array($role, ['Client', 'Freelancer'])) {
        echo "Invalid role selected";
        exit;
    }

    $hashedPassword = password_hash($rawPassword, PASSWORD_DEFAULT);

    // Fix column names with backticks due to spaces
    $stmt = $conn->prepare("INSERT INTO signupform (`Signup as`, `Full Name`, `Email`, `Password`) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $role, $fullName, $email, $hashedPassword);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
