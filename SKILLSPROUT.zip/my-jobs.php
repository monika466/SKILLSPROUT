<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "skill";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM jobs ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>My Posted Jobs - SkillSprout</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet"/>
  <style>
    body {
      margin: 0;
      font-family: 'Inter', sans-serif;
      background-color: #f9f4ef;
      color: #5c4433;
    }

    header {
      background-color: #fff8f2;
      padding: 20px 40px;
      box-shadow: 0 2px 10px rgba(161, 130, 92, 0.08);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header h1 {
      font-size: 1.8rem;
      color: #5c4433;
    }

    main {
      max-width: 900px;
      margin: 40px auto;
      padding: 20px;
    }

    .job-card {
      background: #fffaf5;
      border: 1px solid #dbc9b5;
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 25px;
      box-shadow: 0 4px 12px rgba(92, 74, 51, 0.06);
    }

    .job-card h3 {
      margin-top: 0;
    }

    .job-card p {
      margin: 8px 0;
    }

    .job-card span {
      font-weight: 600;
      color: #8d6f4a;
    }

    a.file-link {
      color: #a1825c;
      text-decoration: underline;
    }

    footer {
      text-align: center;
      font-size: 0.9rem;
      margin: 40px auto 20px;
      color: #a68c76;
    }
  </style>
</head>
<body>
  <header>
    <h1>My Posted Jobs</h1>
    <a href="post-job.html" style="text-decoration:none; background:#a1825c; color:white; padding:10px 20px; border-radius:8px;">Post New Job</a>
  </header>
  <main>
    <?php while ($row = $result->fetch_assoc()): ?>
      <div class="job-card">
        <h3><?= htmlspecialchars($row['title']) ?></h3>
        <p><span>Description:</span> <?= nl2br(htmlspecialchars($row['description'])) ?></p>
        <p><span>Budget:</span> $<?= $row['budget'] ?></p>
        <p><span>Deadline:</span> <?= $row['deadline'] ?></p>
        <p><span>Experience Level:</span> <?= $row['experience_level'] ?></p>
        <p><span>Skills:</span> <?= $row['skills'] ?></p>
        <?php if ($row['file_name']): ?>
          <p><a class="file-link" href="uploads/<?= $row['file_name'] ?>" target="_blank">View Attached File</a></p>
        <?php endif; ?>
      </div>
    <?php endwhile; ?>
  </main>
  <footer>&copy; 2025 SkillSprout. All rights reserved.</footer>
</body>
</html>
