<?php
// Enable errors for debugging (you can disable later)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
session_start();

// DB connection
$host = "localhost";
$dbname = "skill";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle POST login form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $role = $_POST['role'] ?? '';
    $email = $_POST['email'] ?? '';
    $rawPassword = $_POST['password'] ?? '';

    if (empty($role) || empty($email) || empty($rawPassword)) {
        echo "<script>alert('Please fill in all fields.'); window.history.back();</script>";
        exit();
    }

    // Fetch user by role & email
    $stmt = $conn->prepare("SELECT password FROM login_users WHERE role = ? AND email = ?");
    $stmt->bind_param("ss", $role, $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($hashedPassword);
        $stmt->fetch();

        if (password_verify($rawPassword, $hashedPassword)) {
            // Login successful
            $_SESSION['user_email'] = $email;
            $_SESSION['user_role'] = $role;

            // Redirect
            if ($role === 'Client') {
                header("Location: hire.html");
            } else {
                header("Location: explore.html");
            }
            exit();
        } else {
            echo "<script>alert('Incorrect password.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('User not found.'); window.history.back();</script>";
    }

    $stmt->close();
}

$conn->close();
?>
