<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database credentials
$host = "localhost";
$username = "root";
$password = "";
$dbname = "skill";

// Connect to DB
$conn = new mysqli($host, $username, $password, $dbname);

// Connection check
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$projectTitle = $_POST['projectTitle'] ?? '';
$description = $_POST['description'] ?? '';
$deadline = $_POST['deadline'] ?? '';
$budget = $_POST['budget'] ?? '';
$eligibility = $_POST['eligibility'] ?? '';
$skills = $_POST['skills'] ?? '';

$samples = ''; // default value

// File upload logic
if (isset($_FILES['samples']) && $_FILES['samples']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = "uploads/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $fileName = basename($_FILES['samples']['name']);
    $filePath = $uploadDir . time() . "_" . $fileName;

    if (move_uploaded_file($_FILES['samples']['tmp_name'], $filePath)) {
        $samples = $filePath;
    } else {
        echo "<script>alert('Failed to upload file.'); window.history.back();</script>";
        exit();
    }
}

// Insert into DB
$sql = "INSERT INTO job_posts (project_title, description, samples, deadline, budget, eligibility, skills) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("sssssss", $projectTitle, $description, $samples, $deadline, $budget, $eligibility, $skills);

    if ($stmt->execute()) {
        echo "<script>
                alert('🎉 Job Posted Successfully!');
                window.location.href = 'my-jobs.php';
              </script>";
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); window.history.back();</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('SQL Error: " . $conn->error . "'); window.history.back();</script>";
}

$conn->close();
?>
