<script>
const gigs = [
  {
    title: "Web Developer",
    description: "Design responsive websites, landing pages, and portfolios with modern HTML/CSS/JS stacks.",
    requirements: "Knowledge of HTML, CSS, JavaScript. Optional: React or Vue.",
    price: "$300 – $1,500",
    tags: "HTML, CSS, JavaScript, Responsive"
  },
  {
    title: "Graphic Designer",
    description: "Design logos, brand kits, brochures, and flyers using Adobe Suite or Figma.",
    requirements: "Adobe Illustrator/Photoshop or Figma.",
    price: "$100 – $800",
    tags: "Design, Branding, Logo, Figma"
  },
  {
    title: "Content Writer",
    description: "Write SEO blog posts, website content, and eBooks tailored to specific audiences.",
    requirements: "Excellent grammar, research skills, SEO basics.",
    price: "$50 – $500",
    tags: "SEO, Blog, Content, Writing"
  },
  {
    title: "Video Editor",
    description: "Edit YouTube videos, ads, and reels with effects, transitions, and sound syncing.",
    requirements: "Adobe Premiere, DaVinci Resolve or Final Cut Pro.",
    price: "$150 – $1,000",
    tags: "YouTube, Video, Editing, Reels"
  },
  {
    title: "UX/UI Designer",
    description: "Design mobile and web interfaces focused on usability, wireframes, and high-fidelity prototypes.",
    requirements: "Figma, Adobe XD, UX tools.",
    price: "$200 – $2,000",
    tags: "UI, UX, Figma, Wireframe"
  },
  {
    title: "Social Media Manager",
    description: "Grow and manage Instagram, LinkedIn, or TikTok accounts with strategy and content planning.",
    requirements: "Scheduling tools, content creation, analytics.",
    price: "$250 – $1,200",
    tags: "Instagram, Social, Planning, Content"
  },
  {
    title: "App Developer",
    description: "Develop Android/iOS apps using Flutter or React Native with responsive UI and APIs.",
    requirements: "Flutter, React Native, Firebase or REST API knowledge.",
    price: "$500 – $5,000",
    tags: "Mobile, Flutter, React Native, App"
  }
];

const modal = document.getElementById("gigModal");
const closeModal = document.getElementById("closeModal");

document.querySelectorAll(".explore-btn").forEach((btn, index) => {
  btn.addEventListener("click", () => {
    const gig = gigs[index] || gigs[0];
    document.getElementById("modalTitle").innerText = gig.title;
    document.getElementById("modalDescription").innerText = gig.description;
    document.getElementById("modalRequirements").innerText = gig.requirements;
    document.getElementById("modalPrice").innerText = gig.price;
    document.getElementById("modalTags").innerText = gig.tags;
    modal.style.display = "flex";
  });
});

closeModal.addEventListener("click", () => {
  modal.style.display = "none";
});

window.addEventListener("click", (e) => {
  if (e.target === modal) {
    modal.style.display = "none";
  }
});
</script>
